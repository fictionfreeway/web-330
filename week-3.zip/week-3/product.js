/* 
Title: product.js
Author: William Watlington
Date: 6/12/2022
Description: Product class for restaurant app 
*/

export class Product {
    constructor(name, price) {
        this.name = name;
        this.price = price;
    }
}